#include <stdio.h>

int main() {
    char c;
    scanf("%c", &c);
    printf("%c\n", c + 32);
    return 0;
}