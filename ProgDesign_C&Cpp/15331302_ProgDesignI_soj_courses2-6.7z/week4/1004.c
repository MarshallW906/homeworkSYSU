#include <stdio.h>

int main() {
    const float fahrehelt = 72.0;
    printf("%f\n", (fahrehelt - 32.0) * (5.0 / 9.0));
    return 0;
}