#include <stdio.h>

int main() {
    float m;
    scanf("%f", &m);
    printf("%.3f\n", m * 0.305);
    return 0;
}