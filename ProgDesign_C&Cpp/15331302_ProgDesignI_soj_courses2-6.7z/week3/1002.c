#include <stdio.h>

int main() {
    char a[1000];
    gets(a);
    puts(a);
    return 0;
}