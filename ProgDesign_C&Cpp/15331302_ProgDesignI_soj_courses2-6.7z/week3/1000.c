#include <stdio.h>

int main() {
    char c;
    int i, j;
    scanf("%c", &c);
    printf("   %c%c%c%c\n  %c%c%c%c\n %c%c%c%c\n%c%c%c%c\n",
        c, c, c, c, c, c, c, c, c, c, c, c, c, c, c, c);
    return 0;
}